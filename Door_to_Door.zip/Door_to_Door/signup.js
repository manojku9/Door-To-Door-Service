function validateForm(event) {
  event.preventDefault();

  var name = document.getElementById("name").value;
  var phone = document.getElementById("phone").value;
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;
  var repeatPassword = document.getElementById("repeat-password").value;
  var area = document.getElementById("area").value;
  var landmark = document.getElementById("landmark").value;
  var pincode = document.getElementById("pincode").value;
  var city = document.getElementById("city").value;
  var state = document.getElementById("state").value;



  if (name === "" || email === "" || password === "" || repeatPassword === "" || phone === "" || area === "" || landmark === "" || pincode === "" || city === "" || state === "") {
    alert("All fields must be filled out");
    return;
  }

  if (password !== repeatPassword) {
    alert("Passwords do not match");
    return;
  }

  // Prepare data for POST request
  var userData = {
    name: name,
    phone: phone,
    email: email,
    password: password,
    area: area,
    landmark: landmark,
    pincode: pincode,
    city: city,
    state: state
  };

  // Send data to the JSON server
  fetch('http://localhost:3000/users', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(userData)
  })
    .then(response => response.json())
    .then(data => {
      console.log('Success:', data);
      alert('Account created successfully!');
      document.getElementById("signupForm").reset(); // Reset the form after successful submission
    })
    .catch((error) => {
      console.error('Error:', error);
      alert('Error creating account. Please try again.');
    });
}
