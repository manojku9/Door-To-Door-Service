function openForm() {
    event.preventDefault();
    document.getElementById("myForm").style.display = "block";
   
  }
  
  function closeForm() {
    document.getElementById("myForm").style.display = "none";
  }
  function Continue(){
   var mb= document.getElementById("phonenumber").value;
    if( mb.length!=0){
      event.preventDefault();
        document.getElementById("otpform").style.display = "block";
        document.getElementById("myForm").style.display = "none";
        var full= document.getElementById("phonenumber").value;
        document.getElementById("number").innerText="We have sent you a 4 digit OTP on " +full+" edit";
      
    }
  
  }
  function Ac(){
    event.preventDefault();
     var Account= document.getElementById("Account").innerText="Gurukiran";
     document.getElementById("otpform").style.display = "none";
   console.log(Account);
    }


    document.addEventListener('DOMContentLoaded', function () {
      // Fetch user data from the JSON server
      fetch('http://localhost:3000/users')
        .then(response => response.json())
        .then(data => {
          // Assuming you have a user with an id of 1 (adjust accordingly)
          const user = data.find(user => user.id === 1);
  
          // Update the profile link with the user's name
          const usernameElement = document.getElementById('username');
          usernameElement.textContent = user.name;
        })
        .catch(error => console.error('Error fetching user data:', error));
    });
  

    const logoutBtn = document.getElementById('logout-button');
logoutBtn.addEventListener('click', (event) => {
  event.preventDefault();
  localStorage.clear();
  alert("Logged out Successfully")
  window.location.href = "../index.html";
});
