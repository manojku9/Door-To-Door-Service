





// const email = document.getElementById("email");
// const pass = document.getElementById("password");
// const button = document.getElementById("signin");

// button.addEventListener("click", () => {
//   fetch("http://localhost:3000/users", {
//     method: "GET",
//   })
//     .then((res) => res.json())
//     .then((data) => {
//       const comparision = data.find((ele) => ele.email === email.value);
//       if (
//         comparision.email === email.value &&
//         comparision.password === pass.value
//       ) {
//         alert("Logged in Successfully!");
//         localStorage.setItem("token", JSON.stringify(Date.now()));
//         localStorage.setItem("id", JSON.stringify(comparision.id));
//         window.location.href = "/profile/profile.html";
//       } else {
//         alert("You are not registered in!");
//       }
//     });
// });



const email = document.getElementById("email");
const pass = document.getElementById("password");
const button = document.getElementById("signin");

button.addEventListener("click", () => {
  // Check if the email exists in the server
  fetch("http://localhost:3000/users", {
    method: "GET",
  })
    .then((res) => res.json())
    .then((data) => {
      const existingUser = data.find((ele) => ele.email === email.value);

      if (existingUser) {
        // Email exists, now check the password
        if (existingUser.password === pass.value) {
          // Password matches, log in
          alert("Logged in Successfully!");
          localStorage.setItem("token", JSON.stringify(Date.now()));
          localStorage.setItem("id", JSON.stringify(existingUser.id));
          window.location.href = "/login/index.html";
        } else {
          // Password does not match
          alert("Incorrect password. Please try again.");
        }
      } else {
        // Email does not exist
        alert("Account not found. Please sign up.");
      }
    });
});
