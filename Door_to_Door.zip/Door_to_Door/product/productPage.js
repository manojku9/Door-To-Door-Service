var bestseller = [
    {
      // pack: "PACKAGE",
      // name: "Full chocolate | chocolate roll-on waxing",
      // rating: "4.77(293.9k)",
      // price: 849,
      // strikeprice: 899,
      // time: "1 hrs 5 mins",
      // discount: " ₹50% off above 499",
      // thread1: "Eyebrow threading",
      // thread2: "Upper lip threading",
      // thread3: "Chocolate full arms, underarms, full legs",
      // thread4: "",
      // thread5: "",
    },
    {
      // pack: "PACKAGE",
      // name: "Glow getter",
      // rating: "4.76(183.6k)",
      // price: 1619,
      // strikeprice: 1759,
      // time: "1 hrs 25 mins",
      // discount: "",
      // thread1: "Upper lip threading",
      // thread2: "O3+ shine && glow facial",
      // thread3: "",
      // thread4: "",
      // thread5: "",
    },
    {
      // pack: "PACKAGE",
      // name: "Wax & glow",
      // rating: "4.76(61.1k)",
      // price: 2559,
      // strikeprice: 2700,
      // time: "2 hrs 25 mins",
      // discount: "",
      // thread1: "Full legs RICA",
      // thread2: "Full arms, underarms (RICA)",
      // thread3: "Upper lip wax",
      // thread4: "Eybrow threading",
      // thread5: "Elysian firming wine glow facial",
    },
    {
      // pack: "PACKAGE",
      // name: "Wax & glow: (RACA) regular waxing",
      // rating: "4.77(255.4k)",
      // price: 1309,
      // strikeprice: "",
      // time: "1 hrs 10 mins",
      // discount: "",
      // thread1: "Full legs RICA",
      // thread2: "Full arms, underarms (RICA)",
      // thread3: "Upper lip wax",
      // thread4: "Eybrow threading",
      // thread5: "",
    },
    {
      // pack: "PACKAGE",
      // name: "Mani pedi delight",
      // rating: "4.74(41.6k)",
      // price: 1549,
      // strikeprice: 1599,
      // time: "2 hrs 10 mins",
      // discount: " ₹50% off above 1",
      // thread1: "Eyebrow threading",
      // thread2: "Upper lip wax",
      // thread3: "Elysian britis rose manicure",
      // thread4: "Elysian britis roee pedicure",
      // thread5: "",
    },
    {
      // pack: "PACKAGE",
      // name: "Full RICA roll-on waxing",
      // rating: "4.77(292.7k)",
      // price: 1149,
      // strikeprice: 1349,
      // time: "1 hrs 5 mins",
      // discount: " ₹200 off above ₹590",
      // thread1: "Eyebrow threading",
      // thread2: "Upper lip wax",
      // thread3: "RICA White Chocolate Roll-On Full Arms + Full Legs + Underarms",
      // thread4: "",
      // thread5: "",
    },
  ];
  var makeYourOwnPackage = [
    {
      // pack: "PACKAGE",
      // name: "Make your own package - roll on special",
      // rating: "4.76(177.3k)",
      // price: 1384,
      // strikeprice: 1594,
      // time: "1 hrs 50 mins",
      // discount: " 20% 3rd person onwards",
      // thread1: "Full legs (Bikini / Brazilian)(Chocolate Roll-On)",
      // thread2: "Full Arms (Including Underarms) (Chocolate Roll-On) ",
      // thread3: "Eyebrow threading",
      // thread4: "Upper lip threading",
      // thread5: "Face & neck detan",
      // thread6: "Head massage(20 min)",
      // thread7: "",
    },
    {
      // pack: "PACKAGE",
      // name: "Make your own package",
      // rating: "4.77(144.5k)",
      // price: 1800,
      // strikeprice: 2202,
      // time: "2 hrs 50 mins",
      // discount: " 20% 3rd person onwards",
      // thread1: "Elysian Pinacolada Fruit cleanup",
      // thread2: "Full legs Honey ",
      // thread3: "Full arms + Underarms Honey",
      // thread4: "Head massage(20 min)",
      // thread5: "Face & neck bleach",
      // thread6: "Eyebrow threading",
      // thread7: "Upper lip threading",
    },
  ];
  var waxing = [
    {
      name: "Single or Double Bedroom Cleaning",
      rating: "4.81(4.5k)",
      price: 499,
      strikeprice:999,
      image_url:
        "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAKABDgMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAABAgMEBQYHAAj/xABGEAACAQMCAwQGBQgIBgMAAAABAgMABBEFIQYSMRNBUWEiMnGBkbEHFKHB0RUjM0JSU2LwJHJzgpKisuE0Q0TC0vElg8P/xAAaAQADAQEBAQAAAAAAAAAAAAAAAgMBBAUG/8QAKREAAgICAgIABgEFAAAAAAAAAAECEQMSITEEQQUTIjJRYSMGM4Gh8P/aAAwDAQACEQMRAD8A2n/Lb+2f/XWqsP8AhI/ZWV/Ul/tX/wBVarT/APhE9lSiWl0SKNCjTkwijSaVQAa9QFGtMPDvqG4/Pn2fz8qmVCl2eVupJAHlsP8AegaK5E9rhz/CKdjk5gM1Dxk5PjT0B5uvlSc9so4pInp6nx+dN3s/1WznuCvN2UbPgnGcDOKXH6nx+dMajaLf2FzZyn83PE8be8EffTfskcA4r4t1bVfzs17cRZOUiiYosfsx3+dR+B+J9T0/iO3me6u3tiwWaJ5mcOD1O5+2ryf6N9UGpiPUZYfqyb86HJceXhViOHbC2nJtiqMmOcdcY76hLLTousTkkdiUh1V0PMGGQfEV6qLhi9CabFbTuzSxqCWb9YHpV2siOPROavGVojKNWiOF6ilr4+NH9agMhjTHNrTFZ2paerTOadj9QUtlo9CqFGhQMer1er1AHqFer1aAaHca9XqwAA+k3tpXN5kU0p3b20S2KAFl/fRRyzEYbb4UwXIGaMTEsRitoGZI+rMPCR/urT6ac2cefP51lyf0w7+Z/kK02k72MefP51NFJdE0UaSKVTkwijQrwoAIo0BRoA8OvvqNIm7EjvqTSCMk5oNTogcgXc704CEwcdadeMfs7+NNkAYAxselYzZSJcZ9Ae/50qkQ/o1Phn506BtWoQqtd05LyFmHNzqpyqkjII+2uZ3F9DaRyRpZyRTc5iCnG7dwO+229dZkfEhP6vIc1WX+gaXfMZpdPt2nfZpeXlbPtG/h8KlkxKXKOjHlcVRmdA5ltxh+ZUURDHTm3Jx9la60zFAuc5NQbWxhikSJCpEa7BR6OalyP2Uat4EU0I6qhJPZkqGQOxXPpDu92aW1QLVmWRSe81Zsu/SnJOIzinY/UFJK47qUvSgEg16vUO+g0NCvUPfQAa9mhQzQAaBNAmkk0GiC+Hf20C+Rk9KZkb033Gc7UA/c2fM1WMfYrY6SWPXbGRS7cDnOQScU0ue+noRiTJ6YI+VZJGJmRz6Uo/icf5RWm0c5sY/KsqN5G/ic/agrT6K2dPX24qCLS6LEURSFpYpxA0RSc0RQYGjQFGgA0kqCaNeoABUY6fbSeyT9ml0aGAAMDA6UoZxt1oUVNCAiXHokg7DbHxpTMVR8dVIPxqPq3NyryH087V4O72ysAC8g2XPTzrGMJhQrcOWVFGDgKc7Z+dQr6T9Gvd2igj31MOIIyCQWJyTVVOxkkBHRWBPuNY2ai2kBUgqcePnU4KCATk7eNQ5+Xs0bpzAdamr6o9lMKwci+B+NEADYUe6hQYerKcY8d6dwqy28kct1eOvMsERAwOmWY9BWrr5l+kWe4k421hJtnS5IC9cJ1X4gg++sbGirNzd/TQ5tHWDRuyuM7O83OgHwyTWy+j3i5uKrCdpoBDcQMFfkbIbz8q+ftEsZtV1CO3iUlSQHYD1R4mupcP6ynClu+m2lpCwMux3DnI6k9/fU9lfZZY9lwjrLMBsaTzjxrDLxtyyBJ4IjkZHKxyc9KmQcb6aTy3KzQtkjBXPT/wB0+yM+RkXNGrLUnmzUS0vre8QvbTJIF9YA7r7R3VIBB8aYm00Rbl2WbC9560qMMR6Tjl7xjrTzQxucugb2ilCCH90nwqqyVGibjyBF64xj21Ij6n8aaEEP7tfhTiRxpnCCkcrNSMVEczR+DSf/AJitPoBzYA+J+4VlLZub6v8A11P+QVqOHznT19v3CpRKPotM0RSBSgacQXShSBXielADnTrRplWJG9L94A86LAXQzvih/eFRru7FuuMhm7gp61jaSsKJfuo1VwX8xBeXlWNd2bBGBT8OoQSNjn5fNhgN7KxTiwom16mw2ccpDDGcil5pgIGqDJGObfYbVBtXmJMSsoVPDbOfGoGrGWOWTLMWViQSenhT/aDtBMVX01BGD41LfZlXDVIk3jcqcnMCx6hd8Cq95MEFExGv6x/WNT0SRlA9BlPcSMVF1QSi2Yp2bSdw6Z8s1HyM8MEdsjo2CuVB03V31TUvqjQryxjPODgAeYrS+zp3VgOAtWifXLzTBCO3WJnmkkOGLqwHKo8AD17/AAxud1JMIwuMZJxXRjvVNk8lbVEdoUnnbwFNSzFSgwPSbFPYo8aouIOFdH150mvrSJrmP1JygLDyPiKvM7UzctIkZMSqzDfB8Kzs1GMseDLi1mt1K2qW5JEhhHKwXJ2H899YDjC1u9H4kmt7hW7NmDWzI3WE7YJ6k/7V2WHUPSSN1cyNuW5cYGeuD/PXyzXcW6RDrujzQcmbhFLW7rjmVwM7Hz6eG9T+XFHRHLJSVnIYNQS3V4rjlkDNyqwPqE/rD+flQvJXs+wkunMtrytlRglVzkEeRPdnw26VXS9hEnLIhaVG5XTGCpHzpVnqCtO0d26PEf0aMSORu4HwB/nfFL6O203t/wB/gsdG1oxn6xbXktrdyMeVR6SoM7b4wfYRXTtB4nE4S11Z44rwdeXZW8PYT4Vxu0tbgXCpBbmSbnKxwwb4bxOOg91bPSeGddECy3VuqTBgYe1mA+OMn7KdbEsrxvhs6uG+FLBqm0WO9t7FItQkikkXoY84A9/X4VZq9URwNJPgkA0oGmVNLDUCmDsWytqT3sn+kVquHT/QseB+6sdp7fmLQ9/MnyrX8On8xIvg33mpxHfRcA0QaSKOfCqCC6S5wM0FORnNCUjbDDfxOKGaEMqJzMcDvqJPek5WLIA/W8ev4VGu3nEpWTAX9VR0plZFPonGD3fD+RU3J9IZIfjuSqyOHZlXrvgH31HgRrmTmkyxI3Ydwpi5t0dDylsnGBnP2Hb31Qz8TQ6UHgveTtnwuYgXAz/D1qTW7X4QPhGllftyI0A7NTjHic9fZQmmWytXmk8MqD0HmfAVC07VrF1zLIqkDKhhyHPUbfz7Kq7qRtdfmdv6IGI9HpKP2f6u3v6VsI23Offr9Gc9Lo0PB9+2pLezl3ZGlHJnYAb4xWiPhVDwzCLZZ2YrhmULv4D5b1ctKviCO/Bq0eUDRX6rZdu3MGILDDe7vri/GD6xwrrzyaXqUsMN1mcRocrnPpZU5Ayc7jfr4V1Pje/eytLGeDJkS9iUjJAIY4I89jWX+lLTY76TTI4oZJbpjJgqM/mwuX+3FebPNPB50Iy+yaf+h73g1+BngjWOM9fiWa7Sxi03O9w9uQ8g/hGd/bVjx5xANE09TFgzSkpCvcDjqfZVJwGtzcSS6hDNJcGCI2scZ5vzROCc52zgLjG25rG8X8RJr2pxPErrbQKUQOpDc53YkHp3fbXLk8bN5nnpZf7cf1QbKGO12Xn0XXcq8aWhkZnMyyCRs7sSpO/v3rtMmZJoRnHpjauF/R43LxfpZUksZgM+R613GYP9fhYKeUA7476+jypJqjnx9OywzkZqJfHDQf2gqX+qKg6g2Gt/7UVEdEzNI7UFiveKVzDlzgn2VX3MqoxkIYEbkY3x7KDUeu4Y5ruORWwwjf1TjJyuPmfjRgBQjp1zvWFm4uGh601heXpvncFYEkXkkhLlSA5xjG3XBPyGk1bWGsdLaZgguGGE5WOAfHoOlTllUYuT9D44yySUY9s4xOts3FjQ21tJ2BuuXsuf0iuenlt8qsr/AIbVdUaHSC86zuOyZjg5B6Nj5+VaS1cJBNcdmPrM3oqSM8i+A8zWk0XRxY/0m4HNcsPHIjHgPPzrgh5DzZUsfXs9bJBYIOU++kZ3h7g99H1o3FxcidzB6RUnZyd/aK2xYBAcD2CoUEvaTTyHOC3KufAbU/CTJKF7hXrx4R4jdslwsWUE9O6nlams/CiGpHyxkqJStTgaoqtTnNQBhdOgne3txDFK/K6glIyfHfatjocM0KTdrEyZbbmXGdzVjAiQwxxRLyRovKqjoBTnN3U6xJCuYhi+PRAz59KZkF6wPZyQRnx5CxH21KzRztTaIXZlBc6TqsxJfUA3tLL8qhnQdRJx2qH2Sn8K1YOOlV1/een2I9/to0Rqk2UzaJeAfnbmP2doxPypl9KvF/QtE39Z2H3Zq0E6A7E0oXKjvNGqGsoJdE1WZSPrcSgjHKGbp8Kix8K3sRODGSTklX3J99ar6yvjR+sL41mqNszDcM3jelIA5/ilFJXQL5CqpEwVegEq4H21qu2U/rCj26+NZqgszB0vU4TlY5s/wSBvvpS2mrkcoW7HtOK0omUnGTv5VZW8SRKM45++jUHKjmfF1rqVlpC3dysvJFcRsBI2RnOR8qg6vxPd251QTRPGkio9olwhV1LjB5c9VAGfbkV0riTT4dW0lrW4bli7RHY+IUgn7M1x7ji4N9rdzJjCRjsx4DG5x/eLVLL4mLO47rlE93G6Nf8ARWslvwskqac0xa4lIkJO5DEDu7th7q5ZxZZtZ8WatCy8rdu0hHTdgH/767d9GPJFwPp4Pfzt8WNcz+lu37LjWSVd1nt45Cf4sMp/0CrVTM9EPgrK65ZsrFSrc2R3EV1dNfurVlLytKq+sjDJI8jXMfo2tVvdaVHflKRu4PfnlOPtxWiupnLsGyMdfIity+jcfTOopcdsuUbIZQykd4qunuedoVf1kmw3wqPw3ci50a2cZBRezP8Ad2+WKZ1X8zepJnAkIPvG3yqDKF+9zDEvM8yKuOrHFV889tJIW+t2pPgJh0ptX7eFVfcBgN/j91N3tpG1tEABgMx6VlsDN6rw3p97rf5WeeAzKF5Tzq3q9CBzYB+PT4KXS31C4Q6ndloEb1Ixuw8znYeyp0lukZPQ+l30+9uUcj2VCeGGR3JHRiz5MSqLI1nw7HBepcyXbTRqciPkCgEdB7BVxPJyxu3kahws4ypJxUsJ2sTRk+sMVTHihj+1C5c08vM3ZCgQrGo5TjvOdqm2cYVGk/aOAfKoyjA6bgYJqcu0a+yumXRzrs8TSQd6DHFAHekspQ+rUvmpgGjzUBROE8X7xKUJEb1XWpohi/YFe7CL9hfhVPmEtSHzD9ofGiGHjUo28B27NfhQNpB+7Bo3DUYG/j7qzN7NzXkpJb1iK1Rsoc5BZPYaY/I1oSTyHJ76NwSoywkGTg52FKWTJ95rQPoNqekkg99Mnh2IZ7O4YHzXNG6NKUyYQjmx6Ne7U58elWb8OTMf+Mi8N4T/AOVAcNz5ybuEjOf0RH/dRsjStEu499J7ZhuN9qsn4eusjlliIwerEfdUd9AvgowEb+q/44otAN2MjtdxKf2h/PWtAXY1T2VheW90hlhZRvv63d5VaYZR6QI8yMVtoxlfxFqAsdJuJ2OyJnH8/wA71wy9uC8RdixZmOQHG+d665xw2dHvwSAsVuXyehJIA++uF6jMvYHYluXOM4wKpi6bIz7o73wIpThDSA68pNurEeBO9YT6XVT61ZS9JRzqT4r1FdK0aKK30uxgt05Io4ECr4eiNq5h9Mk3/wAtZw53SFmPvIx8jU2yjXBS/RtqKQcS2naDlY8yFsgA8y4762GrjsNXnj2wWx99ct4dcw6zZHlDDt0HKR19KvoK50K0urpri6i55CwO7dwoydIMfshcIXP1fTLkSo2BJlPR9bI339wo6nqn1wrGE5BG+QPP/wBVZ3IVIwqgKo2AHQeystJLG9zJytzEPg8u/dXM2UNFaz/mFP8AET9lTmbmt4R5mqaAn6vEFV2HU8qk4qz5v6PDs/623Idt6EaR7wfd99SGXnVD/CKj3DqZEAOSeoCnapalV5Fyd9s8pz8KEaNJHhjUjPZxFq9tzbMx/wDrb8KZvJUXlj5hz9SMEEeG1MkY3wQbm5EKcx7t/f3VPtZC9srd3dVbe2on0m7YnBAynljc0vQ763ngMQnjMiAFhzAkZ8apJroWN9k52pIevSsmf0ifHFNApn9Kn+IVMeyQH2rxamlZB/zk/wAQolo/3yf4hQBq816qY8S6Wpw0pGTj1G/CnF4h0w/9R8Ub8KLELWjVaNb00/8AVxj27Usatp7dLyD/ABiiwJ2fCqvVNat9PleB0kM31d519A8rBRuM+NHUtatbLT5rqOSOd0X83ErjMjE4VfeSBVHc8SRzW7Q3dmzYDLIFwVbuPfuKpHDlyJ/LVnPm83B4rXz+mOcIcRy6pe31nfSIbiPEiCNcBUPdnxzWq5wy5yD5isZFeqqkW0SQrjZUQAYpzQNZudQ1f6t2ghhjUkr1D4PXuwd6IePnV7pUhMnxbxc+b+KLV0a/IHUge2vVRa21hfP9We5k+sQkEpDIMjPQMO8Gre3hjtoVhhRUjTZVXoB4VzxyqU3Fejr1kvuQ7QzQOaSTVAFGo97cpaWs1w5wsaFvw+2niaquIVjn0yW2khjm7YiNI5QCpYkBeoO4JBz/AA0WBmuKHFxwHq14qsO3A5ecYblyMZ+/zzXDZIhOjhv2T8q+h+K9NUcD39hbcxEVqeTmJyeXckk79xNfPkLICzMOZQCSBXVgf0sjk7PpHTIVOlWbKcMYYzv/AFRXFPpK5rvi3U2GP6FDHGxHQ7c3zY13GwdDp1q0ZBUwpj/CK43xUbSy4h4lj1I8r3qAQFu84BBHl3e6oKX1FPRh9BIj1e2k6lJlYj3ivpC+vILa2a5uJhFEPS5ia+cLGzJvIszxInaDnkDZ5Rncj3V06W5XWrkPLfpMibRLzAAL3beNNldrgyHYrWOJLzVJGg02ExWhPrnZ3/AULGC4jj9QDJBA8NqurLS1QKQi47iDmrJLVRtgCoUURUc9xhOzXAVQOpFWxnlSxtAFBLKebffOakC2XHd8KWsCY3GR5d1YNRW/W7oyeiHVdtg5xUiXUkhgM9wQgiPMS2+NsVIaEH1EzXntkkXs2QFcb+daBk9a4yDxmDRYu1nfbtCQeX2DqTVAJuIBb835Pv3uOiTrC5yO7O3T8K6P9USNeVXmC+UrfjTYjYjlDzgf27/jVG4ekM3GuEYTiPWeINZthpllYvY2jKFmMkiKznwJzkDPhvS9D07iuxntGAtktlZe0ljlXLJ3g5+4VtpLGHcrEpPiRTa2ERGWijYg5GVFY5J+hSQ91+zz48jimvrDZ6P8afaM7EmmnTbxxShR4XvKMen8a99d83pl4jn1T8KHZ42IoCiLJw3K8yymd+YNny+FSzYX3dPH74F/CtJ2XnXuzFZYUZk2V+O+BvbFj5UPqt93w2p/ut+Nafs1xnNDkHfvRYamVmsL2WIobe1U7FW9PZgcg9fEVFuVeAhJAofHpAdM+VbXlUdAKy3E4VL0EYwVFep8Ll/M1+UeD/UGLbxlL2mIhlAt+0PqBMc2RufCqjR2c37FI2cmIkhTgj0v96rb7pkYGx3x8vCpvA13DHqF20r8x7HlHf8ArA/dXZ5vjvHjlO+DzvhTUskeDcTWlnFbrMsHLdSRr2k36x7+vlVRLNdRSlUN66bYZCCD/mq6vjmx51/YzTGlAPahpEPMW6EY7q+PucfL4XDXJ9m/qjyyuW8u16zXi+1f96X+Urxf+ruR7Y2/Cr1YlI9UY8K8baNuqg16BKihGr3g9W9k98Tf+NG81K45bTnn5pATNzFTgdy93tNXTW0KqTgdKhWlulx2twyj035Y89yrsPv+NBlFXeazdXNnPbNdxDto2j3wPWGPvrhjq8glEX6OLY43A9pr6N/J6EjOKstJ0i00vTPqVrbrHE/MzKo2JYk5PxxVceTUSULMDo/FN/a6BpyydgziBRyDDHp7c0i71a71eLs7u2tgCMc/Z5ZR4ZNaaXT7eMmNY1yuwAGwqMLNVPojG+fVqd82PRhuGvo3lm1NLjVJ1exU8/IF/Sj9k+A/CtPqf0a6A79tBFPEr/u5mwvuJxV9D2oCojKceIxUxr27jUrHZLKcfvQB9tFhRgW4CurT0tG4hv4WB9HtQHQeWBim4uKNY4ZvY7LjKFXtZTiK/hGVPt9neDg+GRvXQold4w0kYiZhkoDkCshx+I9Rt/yKWVW5RMZSM8jb8vs8/EHFMuTGqNIl9aMivFMsodQ6lDkFfHPhTUur264VIpHkJxhQAF9pJArBWMdzw9ozxm7uJLboXl9FceCrWfv9YvLvI7Ro4gfUBxTaCfMZ2K1uVuc4XkI7u0ViR4+iTUjkA8c+NfPsWsz2F6J7NnWWNwQ4cg5867ppmqLfaZp2oqqmC7jBPKvRiD9m1I1RSMrJxTJzSSBnpSmubcL+lXJpAu7cHeTfyRj91YOFkAG4pCR5XK7jxotcPLiO3Rskgdoy4AHfjPfSPqztnFzOBnp6G3lutACnT0c9w6mq+fULGFW7S+t0wM7zLk+wZqa1lCSplTtiDsZTz48wDsPcBTxijKFWQFSMFcbGgwozdRSkNJNMc7hYI3ZR/eVTmlpIsknYM7HALBniKnu2IIG+4+2pxsuvYS3CZPQNzf6gaU9u8YHa3aKD+9QfiK0C6JoDPhSOufKlEEAHJqZp7Bz1r3L50Rk0rFACCARg1HuLK3ucfWIY5MftoDUoDehkDrWxk4u0LKMZKmisOgaSx5jp1qT4mIU/DpdnD+it4kHgqACpvMO6jnFNLJKXbMjjhHpDIgjXcIPLIpwClBs91epBzw5cZ8Bk14lQCcjA6nwqm4o0m41nTxa2moPZSCQPzoM82x2PfjesbLwZxdDCy2+q29wp2Ku8kYI9npVq5YrLrjTi2Cx0tF0W5tri9mlEahWDhfaB54rVWcIgs4IsAcsajlHccb1ySThbiq0y66PFK52DW86Ej/Fy4roHCLcQS2sp4lgSFww7FVYE8oA9bBIznPfTOjE2aAlR1xmo99HPdwiOPUbq1AO5gEeT7S6tT/IvXG9KCgUg1EW0tRBGFaR5m75JCCx+AAqRyJj1RS6A3FbYCBGg6DGetJZBjpTp8qT161gDJflz6PfXLvpK0fUPy0utacsrhkQMI2JaIrsDy96n591dXKqRuKQYYzjmQHHlWp0DVnznqmt6reMEvGlJB2UxYx7sVD7PVLn0IobqRvBIj+FfSjWludzDGT4lAaKQovRR8KbcTQ+drfhjiCf9HpF2ObGS6YBPmTXauF7RtK0aysnyzW8IQnwPfirTUZuyVYYwO2k6E78o7zTttGFiCY6UXZqVARw5JI9+Kdhd2BwMAd9F8AeArwPKNtu6gYA3JJOe6iBhTQ6DajnAzQAhtzikuMDOSBSl2APjSuvX4VoEG+tJZZIXQh1UH807sqsdtyR94NIijjh2Om9m3f2IV1PyP2CrAN+cbcbYA/n30rmHTYigGf/Z",
      thread1: "Intense Cleaning with Scrubbing machine(On Floor) and Bed Cleaning",
      thread2: "",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
  
    },
    {
      name: "Kitchen Cleaning",
      rating: "4.78(45.2k)",
      price: 799,
      strikeprice:999,
      image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/w_128,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/home-screen/1659102397467-57a62b.png",
      thread1: "Stain removal of kitchen tiles, slab, sink, floor, exhaust, window, fan, etc",
      thread2: "",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
      name: "Bathrom Cleaning",
      rating: "4.81(29.5k)",
      price: 399,
      strikeprice:479,
      image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/w_128,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1649400304264-c52c8a.jpeg",
      thread1: "Dirt & black stain removal from toilet pot, tiles, floor, basin, exhaust, etc.",
      thread2: "",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
      name: "Full House Cleaning",
      rating: "4.81(4.8k)",
      price: 4999,
      strikeprice:15999,
      image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/w_128,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/home-screen/1630419513189-4526a2.jpeg",
      thread1: "People:2-4|Duration:4-6 hours(depending upon the size of the house)",
      thread2: "",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
  ];
  var facial = [
    {
      name: "Hair Grooming for Women",
      rating: "4.79(49.9k)",
      price: 1049,
      strikeprice:7499,
      image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/w_128,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/luminosity/1696956644904-618ba7.jpeg",
      thread1: "Hair Styling and Scalp Treatment",
      thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
      name: "Skin Care",
      rating: "4.76(64.5k)",
      price: 1099,
      strikeprice:1199,
      image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/images/supply/customer-app-supply/1634707058605-fd6260.png",
      thread1: "7 step process, Glow ingrediants, include 20 min massage",
      thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
      name: "Full Body Massage and Nails Cleaning",
      rating: "4.76(86.6k)",
      price: 2599,
      strikeprice:5999,
      image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/images/growth/luminosity/1658988752247-347188.png",
      thread1: "Relaxing swell gel soak, scrub, skin massgae, mask for fresh, fragrant hands",
      thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
      name: "Face Glow",
      rating: "4.74(14.4k)",
      price: 1299,
      strikeprice:1387,
      image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/images/supply/customer-app-supply/1634707052569-4bc6a6.png",
      thread1: "Tan Removing, Eyebrow threding, Lips Threading",
      thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
  ];
  var manicure = [
    {
        name: "Hair Cutting",
        rating: "4.75(18.6k)",
        price: 349,
        strikeprice:1599,
        time: "15 mins",
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_231,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1700127735237-fc713d.jpeg",
        thread1:"Hair Trimming and Antidandruff treatment",
        thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
        name: "Beard Gromming",
        rating: "4.71(20.2k)",
        price: 149,
        strikeprice:799,
        time: "25 mins",
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_231,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1700127738676-78482d.jpeg",
        thread1:"Beard Saving and Styling",
        thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
        name: "Face Grooming",
        rating: "4.73(6k)",
        price: 549,
        strikeprice:999,
        time: "45 mins",
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_231,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1700127746630-a2db1c.jpeg",
        thread1:"Facial Scrub, Head Message, Facial Bleach",
        thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
        name: "Wax & glow: (RACA) regular waxing",
        rating: "4.72(3.4k)",
        price: 1049,
        strikeprice:1119,
        time: "60 mins",
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_231,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1700127749713-df655c.jpeg",
        thread1:"Body waxing, Body massage",
        thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    }
  ]
  var pedicure = [
    {
        name: "Doctor care",
        rating: "4.76(19.8k)",
        price: 999,
        strikeprice:2449,
        time: "15 mins",
        image_url:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEAY8Bt3bAtVbQ7_FDrCcJmKQit-5C1WDgJw&usqp=CAU",
        thread1:"A doctor may visit a patient at home to diagnose and treat the illness(es). He or she may also periodically review the home health care needs.",
        thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
        name: "Nurse Care",
        rating: "4.73(65.2k)",
        price: 8849,
        strikeprice:9999,
        time: "1 hrs 5 mins",
        image_url:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSo1pKiJUh9iFO1PUiQY33nf9UWqcU7VtjwPw&usqp=CAU",
        thread1:"he most common form of home health care is some type of nursing care depending on the person's needs. In consultation with the doctor, a registered nurse will set up a plan of care. Nursing care may include wound dressing, ostomy care, intravenous therapy, administering medication, monitoring the general health of the patient, pain control, and other health support. ",
        thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
        name: "Medecine delivery",
        rating: "4.72(14.1k)",
        price: 549,
        strikeprice:1149,
        time: "1 hrs 5 mins",
        image_url:
        "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTExIVFRUXFxoXFxYXGBkXHRoYGBcXGRgYFxcZHiggGR0lHRgXITEhJSkrLi4uGB81ODMtNygtLisBCgoKDg0OGhAQGy8lICUvLS8tLS0tLS0vLS0tLS0tLS0tLS0tLS0tLy0tLS0tLS8tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMYA/wMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABgcEBQECAwj/xABGEAACAQIDBAcEBwUGBQUAAAABAgADEQQSIQUGMUETIlFhcYGRBzKhsRQjQlLB0fAzYnKCkhZDU3OishVUs8LhJDRjk9L/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAgMEBQEG/8QANhEAAgECBAIJAwMDBQEAAAAAAAECAxEEITFBElETImFxgZGhwfAFsdEUIzIzQvEkYqKy4RX/2gAMAwEAAhEDEQA/ALxiIgCIiAIiIAiJj4vFJSRqlRgqIpZmPAKBckwDIlTe0D2mNTqNhsERmQlalYgNZhxWmDoSDxY310A5zV74+1SpXVqODVqNM3BqnSow4dQD9nft97X7JlbTPUq7RN1DDW60/I3R3vx5bP8ATcRf/MYD+kdX4SyPZ/7S+lvQxzojAXSu1kVrcVqcFDcwRYHsvxp2CpFrjjqO/lpKozcXc0zowmrW9EfUOD3hwlVglPFUKjHgqVUYnwAN5tZ8kg2II0INwRoQRwIPIz6A9le8jYzCEVWzVaLdGzHiy2ujnvIuCeZUnnNFOrxOxhrYbo1xJk2iIlpmEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBIH7ZcQy7NYA2z1aat4XLW9VEnkqj267UK08PhgNHZqrH/Lsqgebk+QkKj6rLaCvUiU/OZ2qUypsylTa9iCNDwOvKSXZWy3fDAJgTVLHMaruKd7HRUBNyvfz1mFux2Ernvulul0wFatpTPur97vPdN3vnu2KtJXoqA1MWygWuvYO8TebArVWpfW0OgKnKFuCCABYi3Ds8ph7Z2tiaVULSwbVksDnDW15iwBtbvld3csskipiJY/sQ2sKeKq4cj9ugKn96lnNvNWY/wAswMXsqnjXYdE+ExNi2Rx1agHHKdL8RqOHfNRuGHp7QwlTKwXpwmaxt170yM3DmRLqcusmZ60Lwa+ZZn0rERN5xhERAEROjtYE8bDhAO8SD7o77Niq3Q1kVWa5plb201ysCeNufdwk4gCIiAIkR27vqmHxAoLTNQggOQbZc1tFFjmNiOz8pdAEREAREQBERAEREAREQBERAEim/W7gxaUqqi9bDuKiD76ggvT8woI7wO+SuJ40mrMlCTjJSRVvQitiKbFEcKjlH5gOFy2vxBs47iV7TPbH4OvUal0FTIFcGoMubMmnVGmnP17pn7WwYweKw4UqKGIrWynTo2NyVQ34EnMBys9vsgTMYdV4Jfw/KY4Ydt2b0OjUxqik4K9+21vchzYWpcWRra305W/O0wttYLFlB9Hsj5gSXUkZNbjgdeH5iT+4/wAM+gjQ/wB2fQCWfpI836FH/wBGfJepC1pAsLj3db21GliR2Gxt5zz3HwpJppUVbIMwUahchFtTxs50PE2vJDvSadLDVazALkW9zy1HHXXwjcym30WnVqU8lWqudwQQRckqpB1FlI07Se2QjQtO18tS2eKUqTlazd1+SQTWPtvDqSDUAIJBFm4jQ8ps5gPsuixJNNSSbk95m1W3OTV6W37dvG/sdf8AjeH/AMUeh/Kc/wDGqH+KvxmmpNhHrmgKWoJF+sAWFiRfhzHO+o0myO7+GP8Adf6m/Oep03z9CucMdDVQ5/3I7f2iwv8Ajp6zr/aTCf46/H8pGn2FQufquZ+03b4zh9mYdRc0xqVXgzaswUcOVyNeXEz3qdvoef6r/Z/y/B5rhMBTxS4qlicpDFuisSpLAggG114nt9JOMDi0qoHptmU3sbEcCQdD3gymP7Z4ZgDSwFRrsVuzUgAVNmJIYka9otJluXvijqKL0gmvVNJumU5ixYuVXqWN9Tp3yL4di2n0t+vbwv7k+iQjeTeeo1Q4bBsqlVDVsSwzLTDe6qr9uoeSzUYPblTC06jLWaqWt9ZiqnVB5FVQADn1Rx7Z4TUm3ksvnz7XJRg91qBxBxjZmdmLqpIyqfskC1ybWOp4yTSrdg+0LGOhUYNcSy2A6E1FyixstTquAxtzIEsHYeNevQp1alFqDsLtSY3KG5FibDx84JI2MREAREQBERAEREAREQBERAEREA1G8mwaWNo9FVzCzB0dTZkdfdZSeYvPbZ1UuuWppVTqvbS5H21H3WGo7L24gzYyK7yOelGVirKo6ymxBuT58tDpK6k+BcRdRpuq+C/b87yRmieTt84WiebsfhIkm3sWuh6F+9gynzym064jauIqizOqKeIpggnxcm48rSH6qHaWL6fUvt5nbauIOLx9DCKhahQP0jEPxUsudaNO/O1RcxH7vcZNJpd2LdEQABZuXZYW/XdN1LKb4o8XMqrR4ZcC0Xy4nUTtMDGYEVGBJItwsB66i/dLFbcpd9iO4fDVBiFpdEoCVnq9LYXKta2t73OoJItZUF7i0l0wvoA0s9TwzEjlxv4T2wuHyAjMTc85CMVEvr1nVabXzN3I9V94+J+c4nNf3j4n5ziSKTX4jYuGcWbD0iL39xRqO8CSLdbZdHD0AtKklPMSzZQBmNyAWPM2AGs1skOzB9UvgfmYBpNqbDTEhmpsoUg2tqrNwPDgORMrxqD0M9B1uL6o4DAHu7uBlgYcfQsQKXDD12+r7KdTmvg3L/wZib+UKJ6O5K1j1UOVsra2CO4GVWJNlzEXOg4y2PCnnoYK6q1abcG1Japb933j2ZanfcHG4fozSp00pVLlmCgLn197TjbhrqNJMZRpxvQEVAxUqQARxBksw3tRoIA1dKopkqpqLSJSm5GodweBtmHPU6aTypFJ5HuBrzqw6y032f8A7zLGiedKoGAZSCpAII1BB1BBnpKzcIiIAiIgCIiAIiIAieGJrpTRndgqqLsxNgAOZMq/eP2lVHJTCDo0/wAVhdm71U6KPG58J6kVzqxgsy06tVVF2YKO0kAepkT3i3+w2GGWmRXqEaBGBUfxuLgeAufCU9jMTUrNmqu1Ru12LHyvwnphFzhqdusesn8QBuv8wv5hZ7wmWWKb0Vjf4zfvGVnF6/Q0yQCKagWBOpDG7XA75LUWwABJFuJNye8k8fGVTJ5untDpKOQnrU+qe8fZP4eUy4uD4U0dD6PXXSShLV6Pu1Xv4M3kROlaqFUsxsoFye4TAfQmq3k2o2HVWp1GSr9gqbaD3swOjL3EHW077H9qFRbLiaQcffp9VvEqdD5ESEbWx5r1WqHhwUdgHAfj4kzjACxNU8KdiO9zfIvqCx7lM6tGnwQSZ8ji8Y6tdzhktF223fzSxf2ztp0a6hqNVHBF+qQSL9o4g9xmmxG9GRypo3ym183eR2SkVchgwJDA3DA2N+0Ea3ko2Bvm9JgMSgxFPmWAzjvD/a8G9RLopLXMoqV6s0lCXC+dr/dZFkLvZT5o3kQfynr/AGpocw48h+BmkbD0q9SlUw9moV1yrl0yVUuWVhxGZbmx4GmfvCee2N28QgLYdqVXj9W4K+QYG15L9vtKnL6hG9uGS7vwdcRvFRzGxY6n7I7e+eLby0+St8BK62htHEK5UqlNgdVZGJH+sTd7qbwUVIXGUEqAn9qucMo/ep5iGHhbTtkf2+0vj+snneK9fySRt6ByonzYflJ1u9iekw1N7WuDpe/2iOM6bPwGEdA9KnRZSNGUK1/ObJECiwAAHIaD0njcdkX0YVk71J37LJGJtnZy4ii1JtLjqn7rD3WHgZoaNJsdhXpO/R1lvSqnLm4EHMBca6AhuRvxkrLWFzIl9J6HaAfgmIGVu5l9wnx4eZnizVmTqdSan4Pu28n6Nkc9o2wcjF0HVq9bwqDUj+ac7o0KFTYuJSrbJ9f0t+VkBDHsIUKQe4Se7c2cMRQenzIup7GGqn1+BMpfH7OLrUpdJUppUI6WmhsHKk2zDtBv48564OostUZ3VjhZtS/jLNdj3Xv5ln+yrEM+ycGWvcUsmvYjMi/BRJbIr7PsWpwq0QAOhAQAfc+wfS48pKpFqzsa6dRVIKcdGIiJ4TEREAREQBESI+0fbn0bClENqla6LbiFt12HgCB4sIIykoq7IP7Q96Diqpo02+opnl/eOOLHtUcB69lodOJbG5WBwtSklRcGAwVbvUQNmbgxplidLjjpxlhzVerK7ZVCamw1PYNZkVsHVpgM1OogJ6rMrLrx0JHGS3fTa+NoYhkv0CkXXorDMvDN0gGa+nC4tpI0Ns1jTq03dqi1At+kZnsVYMGW50biPAmCMkk2jyxahx0qjibVAPsueduStqR2HMOQnbZG0DQqhxqODDtB4j8fKY+Gr5De1wRZlPBlPEH5g8iAeU74mgFsyklG90nj3q3Yw5+RGhnjSasxGUotTjqsyzMPWV1DqbqwuDInvftfMegQ6A9c9tuA8uff4TVbM2jWpUqgR7LoNdbMx4DsNgx8prUUsQACSTYAakk/MzNSw3BPifgdXF/VOmoqEVZv+X4XY9fTmd8PQaowRRdmNgP1ymzxuzK9xTWhVypf+7e7Mfeci19bAAcgBzvONnOKdWkikEl16RwRawdTkU8Mump5kdgubYwOPVqxt94/aQ9vY00t2MFGipp3ZStfDuhs6Mh7GUqfQzzlp75bu1Mac9JlDUywyObXubk317B8ZXu0tg4mh+1oOo+9bMv9a3HxnqZXUpOD7OZmbpbxPg6p6x6JxlqAa2uLB1H3l494uOy1r7sbMemrl2BV7FcpuDx6wPfcSiryfbhb3NRAo1iWpA2BOpQHhbtHdynudmkRg6anGc9r2eyvrf5kSXfndlcVSZwAK9MXDD7Q7+78pTDKQbHQjQ9xE+k2YEBxYju1up/V5UO9W51XpmeiAQWIIvbW/Ed9spkErm+c1Tld6P0fsnu9E12tkZ2Rt3EYVs1Gqy9o4q38S8DJdsn2pVulo0qyoQ9RVZwLWV2Ck+IvIw+7GLH9w/jpMI7pY6s9qeHqE246L8WIkbFiqQejXmj6MxnuGQ3eWkWpsR7wsynsI1/OSvZxqNh6fSrlqmmudbg2fKMwuNON5H9oi9x2z1OzuJw44uL3VvMkOzMWKtKnVH21DeZGo9byvd+MB0WJLAdWqMw/i4N8bH+aSbcCtmwoU/YZh5aN/wB043/wWfDioBrTYH+Vuq3/AGnylkOrOxixMenwqnvZP8+5FtzMf0WKUE9Wp1T4ngfW3qZaQlIKxBuNCNQe/lLi2RjBWo06g+0oJ8efxvPa0dGVfS6t1Knyz89fX7mdERKTqiIiAIiIAlIe0fanT41wD1KX1S+I98/1XH8olu7d2omFoVKznRRoOZY6Ko7ybT57dyxLMbkkkntJNyfWSiZMVPJROJcm4lUvgqPVIygprpfKTqO4j8ZEPZZhqTV6rOoZkQGnfW1yQzAdo6ov+8ZOtoby0aLFSSWHEAX8r6D4yyEJTdoq5mjOnSjx1JJLtMPfPdRsd0bK6oyXHWBIIa19RzFvjIhtj2f1MOgqdKtVQw6QBShAJtcam49JNcPvFVrXFHDsRyY3t8Bb4zORarpbEUgMxta9wRYnUXNuE9qQlQXFUWSzaur+VySlSxN1Svd6Ss0tOdv87Fcbe2XSp0qTJTUXFyeNzpxv4yPVW6NyMuam9mycLg8MvYwN7H5gkG5nrYZXCXpaEALcG3DS0jftHpBsOKtPRqFVTfLawa3C411KHykJ46E0oKm1nrkuf+NT1/Sa1FyrSk7W0s+zdv23t2kewG5GIqUyP2aM6sGqgq2UK4safHNduHDvkk2ZuhhsMMzlqzkZbkWHDUKgPMA3uTpccCZsTiq1enRr0rBWUM2YlQC1tTp1gNdJssTSSopDLmXjb5WIkGzdTw9KPDJ5p+flkrlae0TZaKaVbDoBTqrlIUAAMuoNuV10/lldV7AgZR36CXltKiMVhKtNEt0YBS17ZlF8ouAb8VPjKO2jpUa4trz0+cy1r8eZvhSVLiilZ3z08NCzfZDtQJUbCsoCVL1Ea32lXrL4ZRf+U9ssTYu01xPSZFKBWsDe4YG9jblw4SrN2Ng1qtNMRSsVQkGzWYHLYjWw1DW0J4ydbr1xhabCuroWa+Yo2XRQTdwLDVjx75ooW6Bzk98s9jLWjJ4hQppvK7sm8zYbS3Wwte+eghP3k+rb1W1/OQreLdWjg16ZK7akL0TgEtcgHKwtwvc6cpZNDFoy3R1cH7SkEfCU/v7tX6RimAN0pfVr4g9c+Z0/lEsT3RhxMIqLUlnp87iZ7hbdt/6WodDfoyeXanzI9OyShhaow7lPzX5BfWUzs3GE2INmWxBHdwPjeW1szaIxCUq3MqwcdjDLf5X8DJVEtUU4Gs3+1LWOndp6fY2KamZeHQDgJo8Rgi7E3Nuy5t6Tc7MpZKSr2X+ZMqOlcy5ENv1VpOQxsbZgO7W3yMl8gHtEe1VQOLUxb+pv15z1K7sQqVFTg5vY2Ps9TLhWc6BnZr9wVQT8D6SK7d35qYrEJg8Plp0ar9EarDMTfS9uQ/VxJDvbV+hbL6IGzuopeba1D6ZvWQ3YuKo4PCo9UhTXqqoPM3JVB/CAWY/xHunsnd3I0KfBSjB7JX9ye7L2PgaJVC/TVDpmfrXPcAMg9JIcLgqVMk06aKToSoA4cjafPu/mHxr4krmzUQAaQJVVAPEW5nMDra/DWRlK2IwrBuvTP36bFfipkSxKysfWcSltxvanUVlpY1ukpnQV7dZP8y3vL38R3y5abhgCCCCLgjUEHgQYPT0iIgCIiAQH2wMfotIcjV18qb2lTS/t6dm0sRh3SqtwOsORDDgQfM+srLEbnIfcqle4qG+VpGVaEHaRTPA1q1500n2Xs/XL1MP2e4ro8cg5VFamfMZh8VEt7C7PojrCmmYkktYE3vxuZUFHd3EUKqVUCvkdX0axOVgbWa3zlw069tLE34W/XHu8ZZGakuqyuFGdJ2qxtyuvsz2q4u1wBqOFzxsLn4TzxFTOqm1ut/2k/jDYbpMxuQDmA8GCgn4H1njXpkHU36x/1ZiB5D1v3CV4jh6KXcX05T6RX0IxvJtarRxBWmwVer9keetu6bnElatLLUUOGHWU/asezs0BnjtTZyvW6RxmUWUKOZtx8NOHOdgbkXNzy5eFvjY8uBleJq0FShGEVxZXdks9Ffm3/bfJuyvnnDC0KyrVJ1JNxf8AFNt2W9uS2ss7enrTxBUm+qk2KnUa8AOz8RPWhRWmuVL5bm1+VyTbw10mODl152FxewtfW3YJ2p1LGxubm1vH5W9LaiVU5un1Zu7fpf1s3tZuN0nqjbJOS6un3t6ZLR7950Y1elGnU1ubra2XQW97Nm58LGarHbSejXKtiAvNQxA6p4cR4jym12nhi6e+ABe5K5tDzHYewiajeHYf0sU3p3NSmcmpym2Zc2a4uGADWGmpmtuyuV1lJ04umo300cV3uXNq7b7CSkt0ahrZiR8uOk1O0sc5xCUqTFctg3Cx7fGwmkq7S2jRxKoylqQW5etTuBbkKlKw7NTfjNvsPFfSaz1ioGUdHYG4zXKmxsL8D6yeFrwcnfVJuz8vcz43C1Ixjnk5JXWezeu2Sf2O+8+MTB4erWRER2AQWUAlje17cct2PkZTEsTfjDV8XiBSQBaVIe8TYF294gcTYWHrMbZ27FGnq31jdraD+nn53lMq1Onl6I9/R4jEzvay5v23eWm2WxDsHW6EdM9Ko1I3TMot1uOhOhItw75KNyt7cOlXo2qFVc3GcEWYKw1tcC4NuPITE3yrV0xezxRDMq1S601HF1ZLqBw6ykjwvLTx+62Cr61MLSJPMLlPqtjJwquUb7MjPAxpVLN9aO/PLdcvHxNRjd98JRut3qMPurp/U1gfK81GI9pL8KWHUa8XYtp4KBY+c2WK9nGHP7KtWpd2YVF9HF/jNJjPZziF/Z1KFT+VqLeozCSyHFVWsU+5/m3/AGNjhfaYP7zDHxR7/BgPnOcPi12hj6VRVYU6aBiGAvpc8iR7zD0kUxW6+KpHr4avbtTJVH+i7fCTjcPAGhRq16qsmb7wKkU0F72Ooub8ewT1dVNlNSTqzjDhaV7u65ZpeZFva1tPPiEoA6Uluf431+ChfWV2+HatiVp1c3R0qYcK17EPYiwPJrrw4gSRUaT7Qx1tb16pJ/dS9yf5UHwmx31oCntPEqosBQwwUdiqHWw9BIGwke5u1sNVamK/RlzekuexOfTgD94W8zM2jSwxxVTAVKHS0alyr5QVRstymYG4Nha47B2yvsTg69PDfSqeFolACge5qMz3uSaZJCsAGtYa6TKwSZkp6NT6amcyXN1YaEjn+jAIdvTsulhMW9KhVFWgT1HGtjzQngSOFxodJcHsW24a2FfDObthyMv+U9yo8iGHhllWbzYCkmFupr9KlUBs9Ho6dtVOR7nMb2I4acpIvYniSNoFeT0Gv4hkYfj6wC+IiIAiIgGBto2oP4D4kCQ+S3b/AOxbxX/cJEphxX813HWwH9N9/sj3wVEO4U3t3SQoQBbW1rfrvmg2afrB5/IzeKt+AldOco/xPMXFSklLQyVxRHP4TpUqBuJ53+FpwmHPPSKjU0tmYXPAHifBRqfKW3qSVnoZOGCeRxUUNe+t+M8loKOd/H9c5l0K2b7LKOWYZb+C8R5gcZjVFsSJ5K8WpbnsUndHX6Ovab9tx5Tj6KutmIvbgRoByFxwnMStSs7pZ/F9ifCdqlBWUq2oIsf0JxgcKtIWQaXJ1NySeJJM63nF5PppczzgVuHYzA5veeNGgFzWAGY5j4m35Ty1jNPenmtyDoQ5I1G1MKKbCxJzXOvG/OYcz9sN1l8PxmBM71OrSbcFc3G7NJSzMVBZR1WIFwDxseV7D0kmtI7ur7z+A+ZkjnQw/wDTRysZ/Wfh9kdSs4sZ3iXGU85EvaJtQJhXo0zmq1bIEXrMFPvGw1AsCPOTGIBXXsu3celnxNamyMRkpqwscvFmsdRfQC/Ye2aj2u4Q0cZh8Vb6qtTOGqNyVw2ekT43b+ky3JrdvbHpYyhUw9Zc1OoLHtB4hlPJgbEHugFabm7XpIKmExQHQ1Te5Ngj6DU8gbDrciPMZG6GHpja9agRnWmrmmzHMeqUt3HRifISG7ewNfZj9DjFZqXCjilFw45K45OBy46cxrNbhN5FoVDVpVyDYi6Bg1jy1AA4DnygFge3zatMYelhrg1GqCpbmqqCLnxvNN7D8AWxtSr9mlRKn+J2UD4K0gWavj8QCFeo7GyJqzHxJ9Sx7OwT6H3A3YGz8KKZsarnPVYcM1rBR3KNPU84BKIiIAiIgGs3gQmg1uRB+MicndRAwIOoIsfAyF47DmlUZOzge0HhMWJhmpHTwFRWcPE52d+0Xz+RkgqYrIo90X0GY217ABck21sJHsAfrF8ZIqNzcBrE8Da9u3SVUnZksWs0Y56R/vkf/Qn41fkDPPDovBWvc6iguUH+OrqSR/ED3TOGBQ+/eof3zceOX3R5CdsUmYAZrC4vqQSByBGo5eV5pMJ1VKVLMRlBAGY8W14XPvG54ds6Y5gvXJAUAkk8raknynnTpU11tnYG+dwC17AaNbsAHlMfblQnD1f8qp/sMrlKLVicU1mYP9p8H/zKes2GExSVUD03Dob2Yag2JB+IlECW5uD/AOxo+L/9V5KtQUI3TMuFxcq0+FpLK/2/JICJ0Djt55fOdyP1+E1Vdjmb+K8yt2Oilc204tPDAkldddTMieo8NPtb3/IfMzDmVtQ/WHwHymLIM6FNdREj3Zw9kZz9o2HgP/N/SbyYmzVtSpj90fEXmXOpTjwwSOJXnx1JPtEREmVCIiAIiIB4YrDJVQpURXRhZlYBgR2EHQyI1/ZbspmzfRct+SVKijyUNYeVpNYgGq2Lu9hcILYeglO/EgXY+Lm7HzM2sRAEREAREQBI/vPh/dqD+E/Mfj6yQTGx1DpKbJ2jTx5H1ldWPFFotoVOjqKRDcIeuviPnJCjWN+cj9AEOoPEML+s3850Tp4lZo9Grk906TiJJtvUzpJEYq794VWZT0l1JU9QcQbHnMXaG/OFelUQCpdlZRdBxKkDnK92n+2q/wAbfMzFnQWGh2nElj6t2svnicyebrb3YfD4VKVTpMy5r2UEaszDW/YZA4ls4KaszNSrSovij3Zlo/2/wn/yf0D/APU2Jqh+uODAML9jC4+cpwy3MD+yp/5af7BMGKoxglY6+AxM60pcVsrafGbjZ/ueZmTMbZ/ueZmTM60Nz1NFtA/WN+uQnlQp5mVe0gepnfFNd28T85nbvUM1YHkoJ8+A+d/KIx4pJG6Uujp8XJErAtOYidU4AiIgCIiAIiIAiIgCIiAIiIAiIgCIiARbbmHyVgw4MQ3mCL/n5z0+nL2H4fnNntvDZ6RtxXrDy4/CaD6M/wB0zm148E8tzo058dON9Vl+PQzPpy9h+H5x9OXv9BMP6M/3TH0Z/umVXZKyM6niEY2A18BPPa6j6PV0H7N/9hmMuGb7p8p746kTQqKoYlkcAHjcoQAO3W0lB5kZ5JlICW5uEB9BpaDjU/6jytRu9iv+Wqf0GWfuVh3p4OklRSjDPdWFiL1GIuPAzoYlpw8fycb6fGUajumsns+aN3lHYJqcT77eM281GJ99vGc2R24szsB7nmZkzG2f7nmZkE2k4q5CTSu2R6sesfE/OSfd7C5KWY8X18uX4nzmgwGENSoF5cWPYOcmaiwsOAl+Fhd8RPH1LJU/M7RETacwREQBERAEREAREQBERAEREAREQBERAMHF44I2XLft85qnbW8RJqK413P2M9SclF57r3OFqkT0FbuiJmxsIqMZJZv8GjATlKUot5Je52DjvnbNOInPudEMezunaIkjw4BmpxPvt4xEjPQlEzMG1k8zBM5idPCRShfc5WOk+O2xsNiqozWFje5Pb+tfWbWIlsopOyFOTlBNiIiRJiIiAIiIAiIgCIiAIiIAiIgH/9k=",
        thread1:"24x7 Medicine delivery service at your doorstep. ",
        thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
    {
        name: "Physical, occupational, and/or speech therapy",
        rating: "4.76(2.8k)",
        price: 12499,
        strikeprice:1299,
        time: "1 hrs 15 mins",
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/images/growth/luminosity/1657525546690-54cb72.png",
        thread1:"Some patients may need help relearning how to perform daily duties or improve their speech after an illness or injury. A physical therapist can put together a plan of care to help a patient regain or strengthen use of muscles and joints. An occupational therapist can help a patient with physical, developmental, social, or emotional disabilities relearn how to perform such daily functions as eating, bathing, dressing, and more. A speech therapist can help a patient with impaired speech regain the ability to communicate clearly.",
        thread2:"",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    }
  ]
  var threading = [
    {
        name: "psychotherapy",
        rating: "4.77(22.2k)",
        price: 19999,
        strikeprice:790000,
        image_url:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdCsZc6yBLmM2eDFRFY1bG3T5wlw_mPqeDbIAdHVSrdA&s",
        thread1:"This approach focuses on changing problematic behaviors, feelings, and thoughts by discovering their unconscious meanings and motivations ",
        thread2: "recommonded to all skin type, peticular sensitive skin",
      thread3: "",
      thread4: "",
      thread5: "",
      thread6: "",
    },
  ]
  var bleach = [
    {
        name: "Double-Door(Inveter) Refrigerator Checkup",
        rating: "4.75(52.5k)",
        price:99,
        strikeprice:349,
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_231,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1700137613735-a7d95a.jpeg",
        thread1:"Price includes visit & diagnosis, Spare parts rates applicabe as per ratecard",
        thread2: "",
        thread3: "",
        thread4: "",
        thread5: "",
        thread6: "",
    },
    {
        name: "Double-Door(Non-Inveter) Refrigerator Checkup",
        rating: "4.75(52.5k)",
        price:99,
        strikeprice:349,
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template/w_231,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1700137613735-a7d95a.jpeg",
        thread1:"Price includes visit & diagnosis, Spare parts rates applicabe as per ratecard",
        thread2: "",
        thread3: "",
        thread4: "",
        thread5: "",
        thread6: "",
    },
    {
      name: "Single-Door Refrigerator Checkup",
      rating: "4.75(52.5k)",
      price:99,
      strikeprice:349,
      image_url:
      "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/w_128,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/luminosity/1598961374736-f7e457.png",
      thread1:"Price includes visit & diagnosis, Spare parts rates applicabe as per ratecard",
    },
    {
      name: "Side_by_Side_Door Refrigerator Checkup",
      rating: "4.75(52.5k)",
      price:99,
      strikeprice:349,
      image_url:
      "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/w_128,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/growth/luminosity/1598961386297-80403c.png",
      thread1:"Price includes visit & diagnosis, Spare parts rates applicabe as per ratecard",
    }

  ]
  var hairColour = [
    {
        name: "AC Repair(split/window)",
        rating: "4.72(34.9k)",
        price: 249,
        strikeprice:349,
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/w_128,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1677590614257-d2a5df.jpeg",
        thread1:"Detailed issue diagnosis with same day resolution, visit charges of 249 wii be adjusted in the final bill.",
        thread2: "",
        thread3: "",
        thread4: "",
        thread5: "",
        thread6: "",
    },
    {
        name: "Gas leak fix & refill",
        rating: "4.75(63.7k)",
        price: 2500,
        strikeprice:3999,
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/w_128,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1677575120274-944efb.jpeg",
        thread1:"Through diagnosis, leak identification & fixing, gas refill to avoid leakages.",
        thread2: "",
        thread3: "",
        thread4: "",
        thread5: "",
        thread6: "",
    },
    {
        name: "Foam & Power jet AC Service(Window)",
        rating: "4.64(1.2k)",
        price: 549,
        strikeprice:1349,
        image_url:
        "https://res.cloudinary.com/urbanclap/image/upload/t_high_res_template,q_auto:low,f_auto/w_128,dpr_1,fl_progressive:steep,q_auto:low,f_auto,c_limit/images/supply/customer-app-supply/1682671873998-10f34b.jpeg",
        thread1:"Get 2X deeper dust removal with foam + powerjet technology.",
        thread2: "",
        thread3: "",
        thread4: "",
        thread5: "",
        thread6: "",
    }
  ]
  bestsellerdisplay();
  makeyourownpackageDisplay();
  waxingdisplay();
  facialdisplay();
  manicuredisplay();
  pedicuredisplay();
  threadingdisplay();
  bleachdisplay();
  haircolourdisplay();
  
  //event & localStorage
  var cartpage=JSON.parse(localStorage.getItem("items"))||[];
  var total=(localStorage.getItem("totalvalue"))||0;
  
  
  function bestsellerdisplay() {
    var section = document.createElement("section");
    section.setAttribute("id", "bestsellar");
    var head = document.createElement("h1");
    head.setAttribute("id", "heading");
    head.innerText = "Bestseller bestseller";
    section.append(head);
    bestseller.map(function (elem) {
      var parentdiv = document.createElement("div");
      var packp = document.createElement("h5");
      packp.innerHTML = '<i class="fa-solid fa-box"></i> ' + elem.pack;
      packp.setAttribute("class", "packagecolor");
      var namep = document.createElement("h3");
      namep.innerText = elem.name;
      var addbtn= document.createElement("button");
      addbtn.innerText="Add";
      addbtn.setAttribute("class","add");
      addbtn.style.marginLeft="80%";
      addbtn.addEventListener("click",function(){addToCart(elem);} );
    
  
      var ratingp = document.createElement("p");
      ratingp.innerHTML = '<i class="fa-solid fa-star"></i> ' + elem.rating;
      var pricep = document.createElement("p");
      pricep.innerHTML = "₹ " + elem.price + "&nbsp &nbsp&nbsp  " + elem.time;
      var edit = document.createElement("button");
      edit.innerHTML = "<b>Edit your package<b>";
      edit.setAttribute("class", "edit");
      var seconddiv = document.createElement("div");
      seconddiv.setAttribute("id", "seconddiv");
      var firstdiv = document.createElement("div");
  
      var thread1p = document.createElement("p");
      thread1p.innerText = elem.thread1;
  
      var thread2p = document.createElement("p");
      thread2p.innerText = elem.thread2;
  
      var thread3p = document.createElement("p");
      thread3p.innerText = elem.thread3;
  
      var thread4p = document.createElement("p");
      thread4p.innerText = elem.thread4;
  
      var thread5p = document.createElement("p");
      thread5p.innerText = elem.thread5;
      seconddiv.append(thread1p, thread2p, thread3p, thread4p, thread5p, edit);
      firstdiv.append(packp, namep,addbtn, ratingp, pricep);
      parentdiv.append(firstdiv, seconddiv);
      section.append(parentdiv);
      parentdiv.setAttribute("id", "parentdiv");
      document.getElementById("productcart").append(section);
    });
  }
  
  function makeyourownpackageDisplay() {
    var section = document.createElement("section");
    section.setAttribute("id", "makeyourownpackage");
    var head = document.createElement("h1");
    head.setAttribute("id", "heading");
    head.innerText = "Make your own package";
    section.append(head);
    makeYourOwnPackage.map(function (elem) {
      var parentdiv = document.createElement("div");
      var packp = document.createElement("h5");
      packp.innerHTML = '<i class="fa-solid fa-box"></i> ' + elem.pack;
      packp.setAttribute("class", "packagecolor");
      var namep = document.createElement("h3");
      namep.innerText = elem.name;
      var addbtn= document.createElement("button");
      addbtn.innerText="Add";
      addbtn.setAttribute("class","add");
      addbtn.style.marginLeft="80%";
      addbtn.addEventListener("click",function(){addToCart(elem);} );
      var ratingp = document.createElement("p");
      ratingp.innerHTML = '<i class="fa-solid fa-star"></i> ' + elem.rating;
      var pricep = document.createElement("p");
      pricep.innerHTML = "₹ " + elem.price + "&nbsp &nbsp&nbsp  " + elem.time;
      var discountp = document.createElement("p");
      discountp.innerHTML = '<i class="fa-solid fa-tag"></i> ' + elem.discount;
      var edit = document.createElement("button");
      edit.innerHTML = "<b>Edit your package<b>";
      edit.setAttribute("class", "edit");
      var seconddiv = document.createElement("div");
      seconddiv.setAttribute("id", "seconddiv");
      var firstdiv = document.createElement("div");
  
      var thread1p = document.createElement("p");
      thread1p.innerText = elem.thread1;
  
      var thread2p = document.createElement("p");
      thread2p.innerText = elem.thread2;
  
      var thread3p = document.createElement("p");
      thread3p.innerText = elem.thread3;
  
      var thread4p = document.createElement("p");
      thread4p.innerText = elem.thread4;
  
      var thread5p = document.createElement("p");
      thread5p.innerText = elem.thread5;
      seconddiv.append(thread1p, thread2p, thread3p, thread4p, thread5p, edit);
      firstdiv.append(packp, namep,addbtn, ratingp, pricep, discountp);
      parentdiv.append(firstdiv, seconddiv);
      section.append(parentdiv);
      parentdiv.setAttribute("id", "parentdiv");
      document.getElementById("productcart").append(section);
    });
  }
  
  function waxingdisplay() {
    var section = document.createElement("section");
    section.setAttribute("id", "waxing");
    var head = document.createElement("h1");
    head.setAttribute("id", "heading");
    head.innerText = "Home Cleaning";
    section.append(head);
    waxing.map(function (elem, index) {
      var parentdiv = document.createElement("div");
  
      var namep = document.createElement("h3");
      namep.innerText = elem.name;
  
      var ratingp = document.createElement("p");
      ratingp.innerHTML = '<i class="fa-solid fa-star"></i> ' + elem.rating;
  
      var pricep = document.createElement("p");
      pricep.innerText = elem.price;
      var seconddiv = document.createElement("dvi");
      seconddiv.append(namep, ratingp, pricep);
      var image = document.createElement("img");
      image.setAttribute("id", "smallimage");
      var thirddiv = document.createElement("div");
  
      image.setAttribute("src", elem.image_url);
      image.setAttribute("alt", index);
      var add = document.createElement("p");
      add.innerText = "Add";
  
     
      add.addEventListener("click",function(){addToCart(elem);} );
  
      thirddiv.append(image, add);
      var firstdiv = document.createElement("div");
      firstdiv.setAttribute("id", "waxingflex");
      firstdiv.append(seconddiv, thirddiv);
      var thread1p = document.createElement("p");
      thread1p.innerText = elem.thread1;
  
      var thread2p = document.createElement("p");
      thread2p.innerText = elem.thread2;
      var fourdiv = document.createElement("div");
      var viewdetils = document.createElement("h3");
      viewdetils.innerHTML = "View Details";
      viewdetils.setAttribute("id", "viewdetais");
      fourdiv.append(thread1p, thread2p, viewdetils);
      fourdiv.setAttribute("id", "desdiv");
      parentdiv.append(firstdiv, fourdiv);
      section.append(parentdiv);
      document.getElementById("productcart").append(section);
    });
  }
  function facialdisplay() {
    var section = document.createElement("section");
    section.setAttribute("id", "facial");
    var head = document.createElement("h1");
    head.setAttribute("id", "heading");
    head.innerText = "Salon for Women";
    section.append(head);
    facial.map(function (elem, index) {
      var parentdiv = document.createElement("div");
  
      var namep = document.createElement("h3");
      namep.innerText = elem.name;
  
      var ratingp = document.createElement("p");
      ratingp.innerHTML = '<i class="fa-solid fa-star"></i> ' + elem.rating;
  
      var pricep = document.createElement("p");
      pricep.innerText = elem.price;
      var seconddiv = document.createElement("dvi");
      seconddiv.append(namep, ratingp, pricep);
      var image = document.createElement("img");
      image.setAttribute("id", "smallimage");
      var thirddiv = document.createElement("div");
  
      image.setAttribute("src", elem.image_url);
      image.setAttribute("alt", index);
      var add = document.createElement("p");
      add.innerText = "Add";
      
      add.addEventListener("click",function(){addToCart(elem);} );
      thirddiv.append(image, add);
      var firstdiv = document.createElement("div");
      firstdiv.setAttribute("id", "waxingflex");
      firstdiv.append(seconddiv, thirddiv);
      var thread1p = document.createElement("p");
      thread1p.innerText = elem.thread1;
  
      var fourdiv = document.createElement("div");
      var viewdetils = document.createElement("h3");
      viewdetils.innerHTML = "View Details";
      viewdetils.setAttribute("id", "viewdetais");
      fourdiv.append(thread1p, viewdetils);
      fourdiv.setAttribute("id", "desdiv");
      parentdiv.append(firstdiv, fourdiv);
      section.append(parentdiv);
      document.getElementById("productcart").append(section);
    });
  }
  
  function manicuredisplay() {
    var section = document.createElement("section");
    section.setAttribute("id", "manicure");
    var head = document.createElement("h1");
    head.setAttribute("id", "heading");
    head.innerText = "Salon for Men";
    section.append(head);
    manicure.map(function (elem, index) {
      var parentdiv = document.createElement("div");
  
      var namep = document.createElement("h3");
      namep.innerText = elem.name;
  
      var ratingp = document.createElement("p");
      ratingp.innerHTML = '<i class="fa-solid fa-star"></i> ' + elem.rating;
  
      var pricep = document.createElement("p");
      pricep.innerText = elem.price;
      var seconddiv = document.createElement("dvi");
      seconddiv.append(namep, ratingp, pricep);
      var image = document.createElement("img");
      image.setAttribute("id", "smallimage");
      var thirddiv = document.createElement("div");
  
      image.setAttribute("src", elem.image_url);
      image.setAttribute("alt", index);
      var add = document.createElement("p");
      add.innerText = "Add";
  
     
      add.addEventListener("click",function(){addToCart(elem);} );
  
      thirddiv.append(image, add);
      var firstdiv = document.createElement("div");
      firstdiv.setAttribute("id", "waxingflex");
      firstdiv.append(seconddiv, thirddiv);
      var thread1p = document.createElement("p");
      thread1p.innerText = elem.thread1;
      var fourdiv = document.createElement("div");
      var viewdetils = document.createElement("h3");
      viewdetils.innerHTML = "View Details";
      viewdetils.setAttribute("id", "viewdetais");
      fourdiv.append(thread1p,  viewdetils);
      fourdiv.setAttribute("id", "desdiv");
      parentdiv.append(firstdiv, fourdiv);
      section.append(parentdiv);
      document.getElementById("productcart").append(section);
    });
  }
  
  function pedicuredisplay() {
    var section = document.createElement("section");
    section.setAttribute("id", "pedicure");
    var head = document.createElement("h1");
    head.setAttribute("id", "heading");
    head.innerText = "Health Care";
    section.append(head);
    pedicure.map(function (elem, index) {
      var parentdiv = document.createElement("div");
  
      var namep = document.createElement("h3");
      namep.innerText = elem.name;
  
      var ratingp = document.createElement("p");
      ratingp.innerHTML = '<i class="fa-solid fa-star"></i> ' + elem.rating;
  
      var pricep = document.createElement("p");
      pricep.innerHTML = elem.price+"&nbsp  &nbsp &nbsp &nbsp &nbsp "+ elem.time;
      var seconddiv = document.createElement("dvi");
      seconddiv.append(namep, ratingp, pricep);
      var image = document.createElement("img");
      image.setAttribute("id", "smallimage");
      var thirddiv = document.createElement("div");
  
      image.setAttribute("src", elem.image_url);
      image.setAttribute("alt", index);
      var add = document.createElement("p");
      add.innerText = "Add";
      
      add.addEventListener("click",function(){addToCart(elem)} );
      thirddiv.append(image, add);
      var firstdiv = document.createElement("div");
      firstdiv.setAttribute("id", "waxingflex");
      firstdiv.append(seconddiv, thirddiv);
      var thread1p = document.createElement("p");
      thread1p.innerText = elem.thread1;
  
  
      var fourdiv = document.createElement("div");
      var viewdetils = document.createElement("h3");
      viewdetils.innerHTML = "View Details";
      viewdetils.setAttribute("id", "viewdetais");
      fourdiv.append(thread1p,  viewdetils);
      fourdiv.setAttribute("id", "desdiv");
      parentdiv.append(firstdiv, fourdiv);
      section.append(parentdiv);
      document.getElementById("productcart").append(section);
    });
  }
  function threadingdisplay() {
    var section = document.createElement("section");
    section.setAttribute("id", "threading");
    var head = document.createElement("h1");
    head.setAttribute("id", "threading");
    head.innerText = "Therapies";
    section.append(head);
    threading.map(function (elem, index) {
      var parentdiv = document.createElement("div");
  
      var namep = document.createElement("h3");
      namep.innerText = elem.name;
  
      var ratingp = document.createElement("p");
      ratingp.innerHTML = '<i class="fa-solid fa-star"></i> ' + elem.rating;
  
      var pricep = document.createElement("p");
      pricep.innerHTML = elem.price;
      var seconddiv = document.createElement("dvi");
      seconddiv.append(namep, ratingp, pricep);
      var image = document.createElement("img");
      image.setAttribute("id", "smallimage");
      var thirddiv = document.createElement("div");
  
      image.setAttribute("src", elem.image_url);
      image.setAttribute("alt", index);
      var add = document.createElement("p");
      add.innerText = "Add";
     
      add.addEventListener("click",function(){addToCart(elem);} );
      thirddiv.append(image, add);
      var firstdiv = document.createElement("div");
      firstdiv.setAttribute("id", "waxingflex");
      firstdiv.append(seconddiv, thirddiv);
      var thread1p = document.createElement("p");
      thread1p.innerText = elem.thread1;
  
  
      var fourdiv = document.createElement("div");
      var viewdetils = document.createElement("h3");
      viewdetils.innerHTML = "View Details";
      viewdetils.setAttribute("id", "viewdetais");
      fourdiv.append(thread1p,  viewdetils);
      fourdiv.setAttribute("id", "desdiv");
      parentdiv.append(firstdiv, fourdiv);
      section.append(parentdiv);
      document.getElementById("productcart").append(section);
    });
  }
  function bleachdisplay() {
    var section = document.createElement("section");
    section.setAttribute("id", "bleach");
    var head = document.createElement("h1");
    head.setAttribute("id", "heading");
    head.innerText = "Refrigerator Repair";
    section.append(head);
    bleach.map(function (elem, index) {
      var parentdiv = document.createElement("div");
  
      var namep = document.createElement("h3");
      namep.innerText = elem.name;
  
      var ratingp = document.createElement("p");
      ratingp.innerHTML = '<i class="fa-solid fa-star"></i> ' + elem.rating;
  
      var pricep = document.createElement("p");
      pricep.innerHTML = elem.price;
      var seconddiv = document.createElement("dvi");
      seconddiv.append(namep, ratingp, pricep);
      var image = document.createElement("img");
      image.setAttribute("id", "smallimage");
      var thirddiv = document.createElement("div");
  
      image.setAttribute("src", elem.image_url);
      image.setAttribute("alt", index);
      var add = document.createElement("p");
      add.innerText = "Add";
  
      
      add.addEventListener("click",function(){addToCart(elem);} );
      thirddiv.append(image, add);
      var firstdiv = document.createElement("div");
      firstdiv.setAttribute("id", "waxingflex");
      firstdiv.append(seconddiv, thirddiv);
      var thread1p = document.createElement("p");
      thread1p.innerText = elem.thread1;
  
  
      var fourdiv = document.createElement("div");
      var viewdetils = document.createElement("h3");
      viewdetils.innerHTML = "View Details";
      viewdetils.setAttribute("id", "viewdetais");
      fourdiv.append(thread1p,  viewdetils);
      fourdiv.setAttribute("id", "desdiv");
      parentdiv.append(firstdiv, fourdiv);
      section.append(parentdiv);
      document.getElementById("productcart").append(section);
    });
  }
  function haircolourdisplay() {
    var section = document.createElement("section");
    section.setAttribute("id", "haircolour");
    var head = document.createElement("h1");
    head.setAttribute("id", "heading");
    head.innerText = "AC Installation and Repair";
    section.append(head);
    hairColour.map(function (elem, index) {
      var parentdiv = document.createElement("div");
  
      var namep = document.createElement("h3");
      namep.innerText = elem.name;
  
      var ratingp = document.createElement("p");
      ratingp.innerHTML = '<i class="fa-solid fa-star"></i> ' + elem.rating;
  
      var pricep = document.createElement("p");
      pricep.innerHTML = elem.price;
      var seconddiv = document.createElement("dvi");
      seconddiv.append(namep, ratingp, pricep);
      var image = document.createElement("img");
      image.setAttribute("id", "smallimage");
      var thirddiv = document.createElement("div");
  
      image.setAttribute("src", elem.image_url);
      image.setAttribute("alt", index);
      var add = document.createElement("p");
      add.innerText = "Add";
  
  
      add.addEventListener("click",function(){addToCart(elem);} );
      thirddiv.append(image, add);
      var firstdiv = document.createElement("div");
      firstdiv.setAttribute("id", "waxingflex");
      firstdiv.append(seconddiv, thirddiv);
      var thread1p = document.createElement("p");
      thread1p.innerText = elem.thread1;
  
  
      var fourdiv = document.createElement("div");
      var viewdetils = document.createElement("h3");
      viewdetils.innerHTML = "View Details";
      viewdetils.setAttribute("id", "viewdetais");
      fourdiv.append(thread1p,  viewdetils);
      fourdiv.setAttribute("id", "desdiv");
      parentdiv.append(firstdiv, fourdiv);
      section.append(parentdiv);
      document.getElementById("productcart").append(section);
    });
  }
  
  //product scroll
  
  const sections = document.querySelectorAll("section[id]");
  window.addEventListener("scroll", navHighlighter);
  function navHighlighter() {
    let scrollY = window.pageYOffset;
    sections.forEach((current) => { 
      const sectionHeight = current.offsetHeight;
      const sectionTop =
        current.getBoundingClientRect().top + window.pageYOffset - 50;
      sectionId = current.getAttribute("id");
      if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
        document
          .querySelector("#productfilterbar a[href*=" + sectionId + "]").classList.add("active");
      } else {
        document
          .querySelector("#productfilterbar a[href*=" + sectionId + "]").classList.remove("active");
      }
    });
  }
  
  if(total>0){
    totalprice();
  }
  function addToCart(elem){
    console.log(elem);
    cartpage.push(elem);
    var total= localStorage.getItem("totalvalue")||0;
    total=parseInt(total)+parseInt(elem.price);
    localStorage.setItem("items",JSON.stringify(cartpage));
    localStorage.setItem("totalvalue",total);
    totalprice();
  }
  
  function totalprice(){
      document.getElementById("tag").style.display="flex";
      document.getElementById("cart_button").style.display="flex";
  
     document.getElementById("sprice").innerText="₹ "+(parseInt(localStorage.getItem("totalvalue"))-50);
     document.getElementById("sprice").style.textDecoration="line-through"
    document.getElementById("total").innerText="₹ "+localStorage.getItem("totalvalue");
  }