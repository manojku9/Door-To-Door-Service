function openTab(evt, tabName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the link that opened the tab
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}

// const currentUserID = parseFloat(localStorage.getItem('user'));

// fetch(`http://localhost:3000/users/${currentUserID}`, {
// method: 'GET'
// })


// .then(response => response.json())
// .then(data => {
//    // console.log(data)
//    if (data.id !== undefined) {
//     document.getElementById('show-id').value = data.id || ' ';
//   document.getElementById('show-name').value = data.name || ' ';
//   document.getElementById('show-email').value = data.email || ' ';
//   document.getElementById('show-phone').value = data.phone || ' ';
//   document.getElementById('show-place').value = data.place || ' ';
//   document.getElementById('show-landmark').value = data.landmark || ' ';
//   document.getElementById('show-pincode').value = data.pincode || ' ';
//   document.getElementById('show-city').value =data.city || ' ';
//   document.getElementById('show-state').value = data.state || ' ';
//   } 
  

 
// });

// const editDetailsBtn = document.getElementById('edit-profile');
// editDetailsBtn.addEventListener('click', (event) => {
// event.preventDefault();
// document.getElementById('show-details').style.display = 'none';
// document.getElementById('edit-details').style.display = 'block';
// });

// const updateDetailsBtn = document.getElementById('update-profile');
// updateDetailsBtn.addEventListener('click', (event) => {
// event.preventDefault();

// const userID = document.getElementById('show-id').value;
// const newName = document.getElementById('show-name').value;
// const newEmail = document.getElementById('show-email').value;
// const newPhone = document.getElementById('show-phone').value;
// const newPlace = document.getElementById('show-place').value;
// const newLandmark = document.getElementById('show-landmark').value;
// const newPincode = document.getElementById('show-pincode').value;
// const newCity = document.getElementById('show-city').value;
// const newState = document.getElementById('show-state').value;

// const updatedValues = {
//     id: userID,
//     name: newName,
//     email: newEmail,
//     phone: newPhone,
//     place: newPlace,
//     landmark: newLandmark,
//     pincode: newPincode,
//     city: newCity,
//     state: newState
// };

// fetch(`http://localhost:3000/users`, {
//     method: 'PATCH',
//     headers: {
//         'Content-Type': 'application/json'
//     },
//     body: JSON.stringify(updatedValues)
// })
//     .then(response => response.json())
//     .then(data => console.log(data));

// document.getElementById('edit-details').style.display = 'none';
// document.getElementById('show-details').style.display = 'block';

const logoutBtn = document.getElementById('logout-button');
logoutBtn.addEventListener('click', (event) => {
event.preventDefault();
localStorage.clear();
alert("Logged out Successfully")
window.location.href = "../index.html";
});





document.addEventListener('DOMContentLoaded', function () {
  // Fetch user data from the JSON server
  fetch('http://localhost:3000/users')
    .then(response => response.json())
    .then(data => {
      // Assuming you have a user with an id of 1 (adjust accordingly)
      const user = data.find(user => user.id === 3);

      // Update the profile link with the user's name
      const useridElement = document.getElementById('username');
      useridElement.textContent = user.id;

      const showidElement = document.getElementById('show-id');
      showidElement.textContent = user.id;

      const shownameElement = document.getElementById('show-name');
      shownameElement.textContent = user.name;

      const showphoneElement = document.getElementById('show-phone');
      showphoneElement.textContent = user.phone;

      const showemailElement = document.getElementById('show-email');
      showemailElement.textContent = user.email;

      const showareaElement = document.getElementById('show-area');
      showareaElement.textContent = user.area;

      const showlandmarkElement = document.getElementById('show-landmark');
      showlandmarkElement.textContent = user.landmark;


      const showpincodeElement = document.getElementById('show-pincode');
      showpincodeElement.textContent = user.pincode;

      const showcityElement = document.getElementById('show-city');
      showcityElement.textContent = user.city;

      const showstateElement = document.getElementById('show-state');
      showstateElement.textContent = user.state;


     
    })
    .catch(error => console.error('Error fetching user data:', error));
});

